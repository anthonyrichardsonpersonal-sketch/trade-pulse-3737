import { apiRequest } from "./queryClient";

export const api = {
  // User endpoints
  createUser: (userData: any) => 
    apiRequest("POST", "/api/users", userData),
  
  getUser: (id: string) => 
    fetch(`/api/users/${id}`).then(res => res.json()),
  
  updateUser: (id: string, updates: any) => 
    apiRequest("PUT", `/api/users/${id}`, updates),

  // Trade endpoints
  getTrades: () => 
    fetch("/api/trades").then(res => res.json()),
  
  getTradeOfTheDay: () => 
    fetch("/api/trades/today").then(res => res.json()),
  
  getRecentTrades: (limit = 10) => 
    fetch(`/api/trades/recent?limit=${limit}`).then(res => res.json()),

  // Market data endpoints
  getMarketData: () => 
    fetch("/api/market").then(res => res.json()),
  
  getStockData: (symbol: string) => 
    fetch(`/api/external/stock/${symbol}`).then(res => res.json()),

  // Analytics endpoints
  getPerformanceMetrics: () => 
    fetch("/api/analytics/performance").then(res => res.json()),
};
