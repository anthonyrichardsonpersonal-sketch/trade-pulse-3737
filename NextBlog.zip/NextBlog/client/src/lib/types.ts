export interface MarketIndex {
  symbol: string;
  name: string;
  price: string;
  change: string;
  changePercent: string;
}

export interface StockMover {
  symbol: string;
  name: string;
  price: string;
  change: string;
  changePercent: string;
  color: string;
}

export interface PerformanceMetrics {
  winRate: string;
  averageReturn: string;
  averageHoldTime: string;
  totalTrades: number;
  winningTrades: number;
}

export interface ChartData {
  labels: string[];
  data: number[];
}

export interface UserPreferences {
  riskTolerance: string;
  investmentAmount: string;
  tradingExperience: string;
  assetTypes: string[];
  preferredSectors: string[];
  alertFrequency: string;
}
