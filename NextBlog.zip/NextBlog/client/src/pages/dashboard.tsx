import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import TradeOfTheDay from "@/components/trade-of-the-day";
import MarketOverview from "@/components/market-overview";
import HistoricalPerformance from "@/components/historical-performance";
import AlertPreferences from "@/components/alert-preferences";
import PricingSection from "@/components/pricing-section";
import Footer from "@/components/footer";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <TradeOfTheDay />
      <MarketOverview />
      <HistoricalPerformance />
      <AlertPreferences />
      <PricingSection />
      <Footer />
    </div>
  );
}
