import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Hero from "@/components/sections/hero";
import TradeOfDay from "@/components/sections/trade-of-day";
import MarketOverview from "@/components/sections/market-overview";
import HistoricalPerformance from "@/components/sections/historical-performance";
import AlertPreferences from "@/components/sections/alert-preferences";
import Pricing from "@/components/sections/pricing";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <TradeOfDay />
        <MarketOverview />
        <HistoricalPerformance />
        <AlertPreferences />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}
