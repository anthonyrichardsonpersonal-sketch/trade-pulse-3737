import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';

const portfolioData = [
  { time: '9AM', value: 23950 },
  { time: '10AM', value: 24100 },
  { time: '11AM', value: 24200 },
  { time: '12PM', value: 24050 },
  { time: '1PM', value: 24300 },
  { time: '2PM', value: 24500 },
  { time: '3PM', value: 24650 },
  { time: '4PM', value: 24580 },
];

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-slate-50 to-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold text-primary mb-6">
              Smart Trading Alerts 
              <span className="text-blue-500"> Powered by AI</span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              Get daily trade recommendations backed by technical analysis, news sentiment, and AI insights. 
              Make informed decisions with our "Trade of the Day" alerts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-blue-500 hover:bg-blue-600">
                Start Free Trial
              </Button>
              <Button variant="outline" size="lg">
                View Demo
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <Card className="shadow-2xl border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-slate-800">Portfolio Overview</h3>
                  <span className="text-sm text-slate-500">Real-time</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-sm text-slate-500">Total Value</div>
                    <div className="text-2xl font-bold text-slate-800">$24,580.45</div>
                    <div className="text-sm text-success">+2.4% today</div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-sm text-slate-500">Day's Gain</div>
                    <div className="text-2xl font-bold text-success">+$578.20</div>
                    <div className="text-sm text-slate-500">+2.4%</div>
                  </div>
                </div>
                
                <div className="h-[150px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={portfolioData}>
                      <XAxis dataKey="time" hide />
                      <YAxis hide />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#3B82F6" 
                        strokeWidth={2}
                        fill="#3B82F6"
                        fillOpacity={0.1}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
