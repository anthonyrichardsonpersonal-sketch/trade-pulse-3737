import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, Share, TrendingUp, CheckCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import type { Trade } from "@shared/schema";

const chartData = [
  { period: '1W', price: 145.20, ma: 144.50 },
  { period: '3D', price: 147.80, ma: 145.20 },
  { period: '1D', price: 149.10, ma: 146.80 },
  { period: '4H', price: 148.90, ma: 147.20 },
  { period: '1H', price: 150.42, ma: 148.10 },
  { period: 'Now', price: 150.42, ma: 148.90 },
];

export default function TradeOfTheDay() {
  const { data: featuredTrade, isLoading } = useQuery<Trade>({
    queryKey: ['/api/trades/featured']
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="animate-pulse">
              <CardContent className="p-8">
                <div className="h-64 bg-slate-200 rounded"></div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    );
  }

  if (!featuredTrade) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-600">No featured trade available at the moment.</p>
        </div>
      </section>
    );
  }

  const upside = ((Number(featuredTrade.targetPrice) - Number(featuredTrade.currentPrice)) / Number(featuredTrade.currentPrice) * 100).toFixed(1);
  const risk = ((Number(featuredTrade.currentPrice) - Number(featuredTrade.stopLoss)) / Number(featuredTrade.currentPrice) * 100).toFixed(1);

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">Today's Featured Trade</h2>
          <p className="text-xl text-slate-600">AI-powered recommendation with {featuredTrade.confidenceScore}% confidence score</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-blue-50 to-white border-blue-100 shadow-lg">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row gap-8">
                <div className="lg:w-1/2">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                      <span className="text-white font-bold">{featuredTrade.symbol.slice(0, 2)}</span>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-slate-800">{featuredTrade.companyName}</h3>
                      <p className="text-slate-500">{featuredTrade.sector} • Large Cap</p>
                    </div>
                    <div className="ml-auto text-right">
                      <div className="text-2xl font-bold text-slate-800">${featuredTrade.currentPrice}</div>
                      <div className="text-success text-sm">+1.2% Pre-market</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <Card className="border-slate-200">
                      <CardContent className="p-4">
                        <div className="text-sm text-slate-500">Target Price</div>
                        <div className="text-xl font-bold text-success">${featuredTrade.targetPrice}</div>
                        <div className="text-sm text-slate-500">+{upside}% upside</div>
                      </CardContent>
                    </Card>
                    <Card className="border-slate-200">
                      <CardContent className="p-4">
                        <div className="text-sm text-slate-500">Stop Loss</div>
                        <div className="text-xl font-bold text-danger">${featuredTrade.stopLoss}</div>
                        <div className="text-sm text-slate-500">-{risk}% risk</div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card className="border-slate-200">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-slate-800 mb-3">Trade Rationale</h4>
                      <ul className="space-y-2 text-sm text-slate-600">
                        {(featuredTrade.rationale as string[]).map((reason, index) => (
                          <li key={index} className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-success" />
                            <span>{reason}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="lg:w-1/2">
                  <Card className="border-slate-200 mb-4">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold text-slate-800">Technical Analysis</h4>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-slate-500">Confidence:</span>
                          <span className="text-lg font-bold text-success">{featuredTrade.confidenceScore}%</span>
                        </div>
                      </div>
                      
                      <div className="h-[250px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={chartData}>
                            <XAxis dataKey="period" />
                            <YAxis domain={['dataMin - 2', 'dataMax + 2']} />
                            <Line 
                              type="monotone" 
                              dataKey="price" 
                              stroke="#10B981" 
                              strokeWidth={3}
                              dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                            />
                            <Line 
                              type="monotone" 
                              dataKey="ma" 
                              stroke="#F59E0B" 
                              strokeWidth={2}
                              strokeDasharray="5 5"
                              dot={false}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="border-slate-200 text-center">
                      <CardContent className="p-4">
                        <div className="text-sm text-slate-500">Risk Level</div>
                        <Badge variant="secondary" className="text-lg font-bold capitalize">
                          {featuredTrade.riskLevel}
                        </Badge>
                      </CardContent>
                    </Card>
                    <Card className="border-slate-200 text-center">
                      <CardContent className="p-4">
                        <div className="text-sm text-slate-500">Time Horizon</div>
                        <div className="text-lg font-bold text-slate-800">{featuredTrade.timeHorizon}</div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Button className="flex-1">
                  <Bell className="w-4 h-4 mr-2" />
                  Set Alert
                </Button>
                <Button variant="outline" className="flex-1">
                  <Share className="w-4 h-4 mr-2" />
                  Share Trade
                </Button>
                <Button variant="outline" className="flex-1">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
