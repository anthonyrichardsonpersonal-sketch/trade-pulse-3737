import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface TradeChartProps {
  data?: Array<{
    time: string;
    price: number;
    target?: number;
    stopLoss?: number;
  }>;
}

export default function TradeChart({ data = [] }: TradeChartProps) {
  // Sample data if none provided
  const defaultData = [
    { time: '9:30', price: 150.25, target: 165.00, stopLoss: 142.50 },
    { time: '10:00', price: 151.80, target: 165.00, stopLoss: 142.50 },
    { time: '10:30', price: 153.20, target: 165.00, stopLoss: 142.50 },
    { time: '11:00', price: 152.10, target: 165.00, stopLoss: 142.50 },
    { time: '11:30', price: 154.75, target: 165.00, stopLoss: 142.50 },
    { time: '12:00', price: 156.20, target: 165.00, stopLoss: 142.50 },
  ];

  const chartData = data.length > 0 ? data : defaultData;

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
          <XAxis 
            dataKey="time" 
            tick={{ fontSize: 12 }}
            axisLine={false}
          />
          <YAxis 
            tick={{ fontSize: 12 }}
            axisLine={false}
            domain={['dataMin - 5', 'dataMax + 5']}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'white', 
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
            }}
          />
          <Line 
            type="monotone" 
            dataKey="price" 
            stroke="#3b82f6" 
            strokeWidth={2}
            dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6, stroke: '#3b82f6', strokeWidth: 2 }}
          />
          <Line 
            type="monotone" 
            dataKey="target" 
            stroke="#10b981" 
            strokeWidth={1}
            strokeDasharray="5 5"
            dot={false}
          />
          <Line 
            type="monotone" 
            dataKey="stopLoss" 
            stroke="#ef4444" 
            strokeWidth={1}
            strokeDasharray="5 5"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}