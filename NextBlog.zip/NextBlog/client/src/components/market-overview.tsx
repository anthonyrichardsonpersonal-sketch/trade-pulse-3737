import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, RefreshCw } from "lucide-react";
import type { MarketIndex, TopMover } from "@shared/schema";

export default function MarketOverview() {
  const { data: indices, isLoading: indicesLoading } = useQuery<MarketIndex[]>({
    queryKey: ['/api/market/indices']
  });

  const { data: gainers, isLoading: gainersLoading } = useQuery<TopMover[]>({
    queryKey: ['/api/market/gainers']
  });

  const { data: losers, isLoading: losersLoading } = useQuery<TopMover[]>({
    queryKey: ['/api/market/losers']
  });

  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-primary">Market Overview</h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-500">Last updated: 2 min ago</span>
            <Button variant="ghost" size="sm">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        {indicesLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-20 bg-slate-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {indices?.map((index) => {
              const isPositive = Number(index.changePercent) >= 0;
              return (
                <Card key={index.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-slate-800">{index.name}</h3>
                      <TrendingUp className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="text-2xl font-bold text-slate-800 mb-2">{index.value}</div>
                    <div className="flex items-center gap-2">
                      <span className={isPositive ? "text-success" : "text-danger"}>
                        {isPositive ? '+' : ''}{index.changePercent}%
                      </span>
                      <span className={isPositive ? "text-success" : "text-danger"}>
                        {isPositive ? '+' : ''}{index.change}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
        
        <div className="grid lg:grid-cols-2 gap-8">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-success" />
                Top Gainers
              </h3>
              {gainersLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse bg-slate-50 rounded-lg p-3 h-16"></div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {gainers?.map((stock) => (
                    <div key={stock.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                          <span className="text-white text-xs font-bold">{stock.symbol.slice(0, 1)}</span>
                        </div>
                        <div>
                          <div className="font-semibold text-slate-800">{stock.companyName}</div>
                          <div className="text-sm text-slate-500">${stock.price}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-success font-semibold">+{stock.changePercent}%</div>
                        <div className="text-sm text-slate-500">+{stock.change}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-danger" />
                Top Losers
              </h3>
              {losersLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse bg-slate-50 rounded-lg p-3 h-16"></div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {losers?.map((stock) => (
                    <div key={stock.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                          <span className="text-white text-xs font-bold">{stock.symbol.slice(0, 1)}</span>
                        </div>
                        <div>
                          <div className="font-semibold text-slate-800">{stock.companyName}</div>
                          <div className="text-sm text-slate-500">${stock.price}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-danger font-semibold">{stock.changePercent}%</div>
                        <div className="text-sm text-slate-500">{stock.change}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
