import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AlertPreferences() {
  const [riskTolerance, setRiskTolerance] = useState("conservative");
  const [assetTypes, setAssetTypes] = useState({
    largeCap: true,
    etfs: true,
    smallMidCap: false,
    crypto: false
  });
  const [sectors, setSectors] = useState({
    technology: true,
    healthcare: false,
    finance: true,
    energy: false,
    consumer: false,
    industrial: false
  });

  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">Customize Your Alerts</h2>
          <p className="text-xl text-slate-600">Tailor recommendations to match your trading style and risk tolerance</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card>
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Risk Preferences</h3>
                
                <div className="space-y-6">
                  <div>
                    <Label className="block text-sm font-medium text-slate-700 mb-3">Risk Tolerance</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <Button 
                        variant={riskTolerance === "conservative" ? "default" : "outline"}
                        onClick={() => setRiskTolerance("conservative")}
                        className="h-auto p-3"
                      >
                        Conservative
                      </Button>
                      <Button 
                        variant={riskTolerance === "moderate" ? "default" : "outline"}
                        onClick={() => setRiskTolerance("moderate")}
                        className="h-auto p-3"
                      >
                        Moderate
                      </Button>
                      <Button 
                        variant={riskTolerance === "aggressive" ? "default" : "outline"}
                        onClick={() => setRiskTolerance("aggressive")}
                        className="h-auto p-3"
                      >
                        Aggressive
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="investment-amount" className="block text-sm font-medium text-slate-700 mb-3">
                      Investment Amount
                    </Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select amount range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="under_1000">Under $1,000</SelectItem>
                        <SelectItem value="1000_5000">$1,000 - $5,000</SelectItem>
                        <SelectItem value="5000_25000">$5,000 - $25,000</SelectItem>
                        <SelectItem value="over_25000">Over $25,000</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="trading-experience" className="block text-sm font-medium text-slate-700 mb-3">
                      Trading Experience
                    </Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select experience level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner (&lt; 1 year)</SelectItem>
                        <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                        <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
                        <SelectItem value="professional">Professional</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Asset Preferences</h3>
                
                <div className="space-y-6">
                  <div>
                    <Label className="block text-sm font-medium text-slate-700 mb-3">Asset Types</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="large-cap"
                          checked={assetTypes.largeCap}
                          onCheckedChange={(checked) => 
                            setAssetTypes(prev => ({ ...prev, largeCap: checked as boolean }))
                          }
                        />
                        <Label htmlFor="large-cap" className="text-slate-700">Large Cap Stocks</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="etfs"
                          checked={assetTypes.etfs}
                          onCheckedChange={(checked) => 
                            setAssetTypes(prev => ({ ...prev, etfs: checked as boolean }))
                          }
                        />
                        <Label htmlFor="etfs" className="text-slate-700">ETFs</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="small-mid-cap"
                          checked={assetTypes.smallMidCap}
                          onCheckedChange={(checked) => 
                            setAssetTypes(prev => ({ ...prev, smallMidCap: checked as boolean }))
                          }
                        />
                        <Label htmlFor="small-mid-cap" className="text-slate-700">Small/Mid Cap Stocks</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="crypto"
                          checked={assetTypes.crypto}
                          onCheckedChange={(checked) => 
                            setAssetTypes(prev => ({ ...prev, crypto: checked as boolean }))
                          }
                        />
                        <Label htmlFor="crypto" className="text-slate-700">Crypto (Premium)</Label>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-slate-700 mb-3">Preferred Sectors</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(sectors).map(([sector, checked]) => (
                        <div key={sector} className="flex items-center space-x-2">
                          <Checkbox 
                            id={sector}
                            checked={checked}
                            onCheckedChange={(isChecked) => 
                              setSectors(prev => ({ ...prev, [sector]: isChecked as boolean }))
                            }
                          />
                          <Label htmlFor={sector} className="text-sm text-slate-700 capitalize">
                            {sector}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="alert-frequency" className="block text-sm font-medium text-slate-700 mb-3">
                      Alert Frequency
                    </Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily (Trade of the Day)</SelectItem>
                        <SelectItem value="2-3_weekly">2-3 times per week</SelectItem>
                        <SelectItem value="weekly">Weekly digest</SelectItem>
                        <SelectItem value="as_needed">As opportunities arise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8 text-center">
            <Button size="lg">Save Preferences</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
