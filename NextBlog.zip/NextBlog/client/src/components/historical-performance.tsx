import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Trophy, Clock, CheckCircle, X } from "lucide-react";
import type { Trade } from "@shared/schema";

export default function HistoricalPerformance() {
  const { data: trades, isLoading } = useQuery<Trade[]>({
    queryKey: ['/api/trades']
  });

  const completedTrades = trades?.filter(trade => trade.status === 'completed') || [];
  const winningTrades = completedTrades.filter(trade => Number(trade.result) > 0);
  const winRate = completedTrades.length > 0 ? (winningTrades.length / completedTrades.length * 100).toFixed(0) : '0';
  const avgReturn = winningTrades.length > 0 
    ? (winningTrades.reduce((sum, trade) => sum + Number(trade.result || 0), 0) / winningTrades.length).toFixed(1)
    : '0';
  const avgDuration = completedTrades.length > 0
    ? (completedTrades.reduce((sum, trade) => sum + (trade.duration || 0), 0) / completedTrades.length).toFixed(1)
    : '0';

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">Historical Performance</h2>
          <p className="text-xl text-slate-600">Track record of our "Trade of the Day" recommendations</p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-white w-6 h-6" />
              </div>
              <div className="text-3xl font-bold text-success mb-2">{winRate}%</div>
              <div className="text-slate-600 font-medium">Win Rate</div>
              <div className="text-sm text-slate-500 mt-2">Last 30 days</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-50 to-sky-50 border-blue-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="text-white w-6 h-6" />
              </div>
              <div className="text-3xl font-bold text-blue-600 mb-2">+{avgReturn}%</div>
              <div className="text-slate-600 font-medium">Average Return</div>
              <div className="text-sm text-slate-500 mt-2">Winning trades</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-white w-6 h-6" />
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-2">{avgDuration}</div>
              <div className="text-slate-600 font-medium">Avg Hold Time</div>
              <div className="text-sm text-slate-500 mt-2">Days to target</div>
            </CardContent>
          </Card>
        </div>
        
        <Card className="bg-slate-50">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-800">Recent Trade History</h3>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm">30D</Button>
                <Button size="sm">90D</Button>
                <Button variant="outline" size="sm">1Y</Button>
              </div>
            </div>
            
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-white rounded-lg p-4 h-16"></div>
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-200">
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Date</th>
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Symbol</th>
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Entry Price</th>
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Target</th>
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Result</th>
                      <th className="text-left py-3 text-sm font-semibold text-slate-600">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {completedTrades.map((trade) => {
                      const isWin = Number(trade.result) > 0;
                      return (
                        <tr key={trade.id} className="hover:bg-white transition-colors">
                          <td className="py-4 text-sm text-slate-600">
                            {new Date(trade.createdAt || new Date()).toLocaleDateString('en-US', { 
                              month: 'short', 
                              day: 'numeric', 
                              year: 'numeric' 
                            })}
                          </td>
                          <td className="py-4">
                            <div className="flex items-center gap-2">
                              <div className="w-6 h-6 bg-blue-500 rounded text-white text-xs flex items-center justify-center font-bold">
                                {trade.symbol.slice(0, 1)}
                              </div>
                              <span className="font-medium text-slate-800">{trade.symbol}</span>
                            </div>
                          </td>
                          <td className="py-4 text-sm text-slate-600">${trade.entryPrice}</td>
                          <td className="py-4 text-sm text-slate-600">${trade.targetPrice}</td>
                          <td className="py-4">
                            <Badge variant={isWin ? "default" : "destructive"} className="font-medium">
                              {isWin ? <CheckCircle className="w-3 h-3 mr-1" /> : <X className="w-3 h-3 mr-1" />}
                              {isWin ? '+' : ''}{trade.result}%
                            </Badge>
                          </td>
                          <td className="py-4 text-sm text-slate-600">{trade.duration} days</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
