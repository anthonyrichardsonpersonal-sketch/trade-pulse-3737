import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Bell, Share, TrendingUp, CheckCircle } from "lucide-react";
import { api } from "@/lib/api";
import TradeChart from "@/components/charts/trade-chart";

export default function TradeOfDay() {
  const { data: trade, isLoading, error } = useQuery({
    queryKey: ["/api/trades/today"],
    queryFn: () => api.getTradeOfTheDay(),
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-slate-200 rounded w-64 mx-auto mb-4"></div>
              <div className="h-6 bg-slate-200 rounded w-96 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (error || !trade) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Trade of the Day</h2>
            <p className="text-slate-600">No trade recommendation available at this time.</p>
          </div>
        </div>
      </section>
    );
  }

  const upsidePercent = ((parseFloat(trade.targetPrice) - parseFloat(trade.currentPrice)) / parseFloat(trade.currentPrice) * 100).toFixed(1);
  const riskPercent = ((parseFloat(trade.currentPrice) - parseFloat(trade.stopLoss)) / parseFloat(trade.currentPrice) * 100).toFixed(1);

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Today's Featured Trade</h2>
          <p className="text-xl text-slate-600">AI-powered recommendation with {trade.confidenceScore}% confidence score</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-50 to-white rounded-2xl p-8 border border-blue-100 shadow-lg">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-1/2">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold text-sm">{trade.symbol}</span>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-800">{trade.companyName}</h3>
                    <p className="text-slate-500">{trade.sector} • Large Cap</p>
                  </div>
                  <div className="ml-auto text-right">
                    <div className="text-2xl font-bold text-slate-800">${trade.currentPrice}</div>
                    <div className="text-green-600 text-sm">+1.2% Pre-market</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-white rounded-lg p-4 border border-slate-200">
                    <div className="text-sm text-slate-500">Target Price</div>
                    <div className="text-xl font-bold text-green-600">${trade.targetPrice}</div>
                    <div className="text-sm text-slate-500">+{upsidePercent}% upside</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-slate-200">
                    <div className="text-sm text-slate-500">Stop Loss</div>
                    <div className="text-xl font-bold text-red-600">${trade.stopLoss}</div>
                    <div className="text-sm text-slate-500">-{riskPercent}% risk</div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg p-4 border border-slate-200">
                  <h4 className="font-semibold text-slate-800 mb-3">Trade Rationale</h4>
                  <ul className="space-y-2 text-sm text-slate-600">
                    {Array.isArray(trade.rationale) ? trade.rationale.map((reason: string, index: number) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                        <span>{reason}</span>
                      </li>
                    )) : (
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                        <span>Strong technical indicators support this trade</span>
                      </li>
                    )}
                  </ul>
                </div>
              </div>
              
              <div className="lg:w-1/2">
                <div className="bg-white rounded-lg p-4 border border-slate-200 mb-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-slate-800">Technical Analysis</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-slate-500">Confidence:</span>
                      <span className="text-lg font-bold text-green-600">{trade.confidenceScore}%</span>
                    </div>
                  </div>
                  <div className="h-64">
                    <TradeChart symbol={trade.symbol} />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white rounded-lg p-4 border border-slate-200 text-center">
                    <div className="text-sm text-slate-500">Risk Level</div>
                    <div className="text-lg font-bold text-yellow-600">{trade.riskLevel}</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-slate-200 text-center">
                    <div className="text-sm text-slate-500">Time Horizon</div>
                    <div className="text-lg font-bold text-slate-800">{trade.timeHorizon}</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Button className="flex-1 bg-blue-500 hover:bg-blue-600 text-white">
                <Bell className="h-4 w-4 mr-2" />
                Set Alert
              </Button>
              <Button variant="outline" className="flex-1 border-slate-300 hover:border-slate-400 text-slate-700">
                <Share className="h-4 w-4 mr-2" />
                Share Trade
              </Button>
              <Button variant="outline" className="flex-1 border-slate-300 hover:border-slate-400 text-slate-700">
                <TrendingUp className="h-4 w-4 mr-2" />
                View Details
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
