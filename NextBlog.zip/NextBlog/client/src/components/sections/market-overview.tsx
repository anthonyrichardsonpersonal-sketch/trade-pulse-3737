import { useQuery } from "@tanstack/react-query";
import { TrendingUp, TrendingDown, RefreshCw } from "lucide-react";
import { api } from "@/lib/api";

export default function MarketOverview() {
  const { data: marketData, isLoading, refetch } = useQuery({
    queryKey: ["/api/market"],
    queryFn: () => api.getMarketData(),
  });

  const marketIndices = [
    { symbol: "SPX", name: "S&P 500" },
    { symbol: "IXIC", name: "NASDAQ" },
    { symbol: "DJI", name: "Dow Jones" },
    { symbol: "RUT", name: "Russell 2000" },
  ];

  const topGainers = [
    { symbol: "TSLA", name: "Tesla Inc.", price: "235.67", change: "+12.89", changePercent: "+5.8", color: "bg-blue-500" },
    { symbol: "NVDA", name: "NVIDIA Corp.", price: "445.23", change: "+17.98", changePercent: "+4.2", color: "bg-green-500" },
    { symbol: "AMD", name: "Advanced Micro Devices", price: "98.45", change: "+3.52", changePercent: "+3.7", color: "bg-purple-500" },
  ];

  const topLosers = [
    { symbol: "META", name: "Meta Platforms", price: "312.45", change: "-9.02", changePercent: "-2.8", color: "bg-red-500" },
    { symbol: "NFLX", name: "Netflix Inc.", price: "428.90", change: "-8.34", changePercent: "-1.9", color: "bg-orange-500" },
    { symbol: "SNAP", name: "Snap Inc.", price: "9.87", change: "-0.15", changePercent: "-1.5", color: "bg-yellow-500" },
  ];

  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-slate-800">Market Overview</h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-500">Last updated: 2 min ago</span>
            <button 
              onClick={() => refetch()}
              className="text-blue-500 hover:text-blue-600 transition-colors"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {marketIndices.map((index) => {
            const data = marketData?.find((d: any) => d.symbol === index.symbol);
            const isPositive = data ? parseFloat(data.changePercent) > 0 : true;
            
            return (
              <div key={index.symbol} className="bg-white rounded-xl p-6 border border-slate-200 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-slate-800">{index.name}</h3>
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800 mb-2">
                  {data ? data.price : "Loading..."}
                </div>
                {data && (
                  <div className="flex items-center gap-2">
                    <span className={isPositive ? "text-green-600" : "text-red-600"}>
                      {isPositive ? "+" : ""}{data.changePercent}%
                    </span>
                    <span className={isPositive ? "text-green-600" : "text-red-600"}>
                      {parseFloat(data.change) > 0 ? "+" : ""}{data.change}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Top Gainers
            </h3>
            <div className="space-y-4">
              {topGainers.map((stock) => (
                <div key={stock.symbol} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 ${stock.color} rounded-lg flex items-center justify-center`}>
                      <span className="text-white text-xs font-bold">{stock.symbol.charAt(0)}</span>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">{stock.name}</div>
                      <div className="text-sm text-slate-500">${stock.price}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-600 font-semibold">{stock.changePercent}</div>
                    <div className="text-sm text-slate-500">{stock.change}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-slate-200">
            <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-red-600" />
              Top Losers
            </h3>
            <div className="space-y-4">
              {topLosers.map((stock) => (
                <div key={stock.symbol} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 ${stock.color} rounded-lg flex items-center justify-center`}>
                      <span className="text-white text-xs font-bold">{stock.symbol.charAt(0)}</span>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">{stock.name}</div>
                      <div className="text-sm text-slate-500">${stock.price}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-red-600 font-semibold">{stock.changePercent}</div>
                    <div className="text-sm text-slate-500">{stock.change}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
