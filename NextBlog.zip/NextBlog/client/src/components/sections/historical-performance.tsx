import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Trophy, Clock, Check, X } from "lucide-react";
import { api } from "@/lib/api";

export default function HistoricalPerformance() {
  const { data: performance, isLoading } = useQuery({
    queryKey: ["/api/analytics/performance"],
    queryFn: () => api.getPerformanceMetrics(),
  });

  const { data: recentTrades } = useQuery({
    queryKey: ["/api/trades/recent"],
    queryFn: () => api.getRecentTrades(5),
  });

  const historicalTrades = [
    {
      date: "Nov 15, 2024",
      symbol: "AAPL",
      entryPrice: "$148.25",
      target: "$165.00",
      result: "+11.3%",
      duration: "8 days",
      successful: true,
      color: "bg-blue-500"
    },
    {
      date: "Nov 12, 2024",
      symbol: "NVDA",
      entryPrice: "$427.89",
      target: "$480.00",
      result: "-4.2%",
      duration: "5 days",
      successful: false,
      color: "bg-green-500"
    },
    {
      date: "Nov 8, 2024",
      symbol: "MSFT",
      entryPrice: "$378.45",
      target: "$420.00",
      result: "+9.8%",
      duration: "14 days",
      successful: true,
      color: "bg-purple-500"
    },
    {
      date: "Nov 5, 2024",
      symbol: "TSLA",
      entryPrice: "$218.90",
      target: "$260.00",
      result: "+18.8%",
      duration: "7 days",
      successful: true,
      color: "bg-red-500"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Historical Performance</h2>
          <p className="text-xl text-slate-600">Track record of our "Trade of the Day" recommendations</p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-8 border border-green-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-white h-6 w-6" />
              </div>
              <div className="text-3xl font-bold text-green-600 mb-2">
                {isLoading ? "..." : `${performance?.winRate || "73"}%`}
              </div>
              <div className="text-slate-600 font-medium">Win Rate</div>
              <div className="text-sm text-slate-500 mt-2">Last 30 days</div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-sky-50 rounded-xl p-8 border border-blue-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="text-white h-6 w-6" />
              </div>
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {isLoading ? "..." : `+${performance?.averageReturn || "18.7"}%`}
              </div>
              <div className="text-slate-600 font-medium">Average Return</div>
              <div className="text-sm text-slate-500 mt-2">Winning trades</div>
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-xl p-8 border border-purple-200">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-white h-6 w-6" />
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {isLoading ? "..." : performance?.averageHoldTime || "12.5"}
              </div>
              <div className="text-slate-600 font-medium">Avg Hold Time</div>
              <div className="text-sm text-slate-500 mt-2">Days to target</div>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-50 rounded-2xl p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-slate-800">Recent Trade History</h3>
            <div className="flex items-center gap-4">
              <button className="text-sm border border-slate-300 rounded-lg px-3 py-1 hover:bg-slate-100">30D</button>
              <button className="text-sm bg-blue-500 text-white rounded-lg px-3 py-1">90D</button>
              <button className="text-sm border border-slate-300 rounded-lg px-3 py-1 hover:bg-slate-100">1Y</button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Date</th>
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Symbol</th>
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Entry Price</th>
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Target</th>
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Result</th>
                  <th className="text-left py-3 text-sm font-semibold text-slate-600">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {historicalTrades.map((trade) => (
                  <tr key={`${trade.symbol}-${trade.date}`} className="hover:bg-white transition-colors">
                    <td className="py-4 text-sm text-slate-600">{trade.date}</td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <div className={`w-6 h-6 ${trade.color} rounded text-white text-xs flex items-center justify-center font-bold`}>
                          {trade.symbol.charAt(0)}
                        </div>
                        <span className="font-medium text-slate-800">{trade.symbol}</span>
                      </div>
                    </td>
                    <td className="py-4 text-sm text-slate-600">{trade.entryPrice}</td>
                    <td className="py-4 text-sm text-slate-600">{trade.target}</td>
                    <td className="py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        trade.successful 
                          ? "bg-green-100 text-green-800" 
                          : "bg-red-100 text-red-800"
                      }`}>
                        {trade.successful ? (
                          <Check className="h-3 w-3 mr-1" />
                        ) : (
                          <X className="h-3 w-3 mr-1" />
                        )}
                        {trade.result}
                      </span>
                    </td>
                    <td className="py-4 text-sm text-slate-600">{trade.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
