import { Button } from "@/components/ui/button";
import PortfolioChart from "@/components/charts/portfolio-chart";

export default function Hero() {
  return (
    <section className="bg-gradient-to-br from-slate-50 to-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-6">
              Smart Trading Alerts 
              <span className="text-blue-500"> Powered by AI</span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              Get daily trade recommendations backed by technical analysis, news sentiment, and AI insights. 
              Make informed decisions with our "Trade of the Day" alerts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-base font-semibold">
                Start Free Trial
              </Button>
              <Button variant="outline" className="border-slate-300 hover:border-slate-400 text-slate-700 px-8 py-3 text-base font-semibold">
                View Demo
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-6 border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-800">Portfolio Overview</h3>
                <span className="text-sm text-slate-500">Real-time</span>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="text-sm text-slate-500">Total Value</div>
                  <div className="text-2xl font-bold text-slate-800">$24,580.45</div>
                  <div className="text-sm text-green-600">+2.4% today</div>
                </div>
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="text-sm text-slate-500">Day's Gain</div>
                  <div className="text-2xl font-bold text-green-600">+$578.20</div>
                  <div className="text-sm text-slate-500">+2.4%</div>
                </div>
              </div>
              <div className="h-40">
                <PortfolioChart />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
