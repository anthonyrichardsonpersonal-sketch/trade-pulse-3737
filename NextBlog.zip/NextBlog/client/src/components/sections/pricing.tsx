import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, X } from "lucide-react";

export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "per month",
      features: [
        { name: "1 Trade of the Day alert", included: true },
        { name: "Basic technical analysis", included: true },
        { name: "7-day trade history", included: true },
        { name: "Email notifications", included: true },
        { name: "Push notifications", included: false },
        { name: "Advanced AI insights", included: false }
      ],
      buttonText: "Get Started Free",
      buttonVariant: "outline" as const,
      popular: false
    },
    {
      name: "Pro",
      price: "$29",
      period: "per month",
      features: [
        { name: "Daily Trade of the Day alerts", included: true },
        { name: "Advanced technical analysis", included: true },
        { name: "Full trade history", included: true },
        { name: "Push & email notifications", included: true },
        { name: "AI confidence scores", included: true },
        { name: "Risk metrics & stop losses", included: true },
        { name: "Performance tracking", included: true }
      ],
      buttonText: "Start Pro Trial",
      buttonVariant: "default" as const,
      popular: true
    },
    {
      name: "Premium",
      price: "$79",
      period: "per month",
      features: [
        { name: "Everything in Pro", included: true },
        { name: "Crypto trading alerts", included: true },
        { name: "SMS notifications", included: true },
        { name: "Priority support", included: true },
        { name: "Custom sector alerts", included: true },
        { name: "Advanced portfolio tools", included: true },
        { name: "Early access to features", included: true }
      ],
      buttonText: "Get Premium",
      buttonVariant: "outline" as const,
      popular: false
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Choose Your Plan</h2>
          <p className="text-xl text-slate-600">Start free, upgrade when you're ready for advanced features</p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <Card 
              key={plan.name} 
              className={`relative border hover:shadow-lg transition-shadow ${
                plan.popular 
                  ? "border-2 border-blue-500 shadow-xl" 
                  : "border-slate-200"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-slate-800 mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold text-slate-800 mb-2">{plan.price}</div>
                  <div className="text-slate-500">{plan.period}</div>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-3">
                      {feature.included ? (
                        <Check className="h-4 w-4 text-green-600 flex-shrink-0" />
                      ) : (
                        <X className="h-4 w-4 text-slate-400 flex-shrink-0" />
                      )}
                      <span className={feature.included ? "text-slate-700" : "text-slate-400"}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  variant={plan.buttonVariant}
                  className={`w-full py-3 font-semibold ${
                    plan.buttonVariant === "default" 
                      ? "bg-blue-500 hover:bg-blue-600 text-white" 
                      : "border-slate-300 hover:border-slate-400 text-slate-700"
                  }`}
                >
                  {plan.buttonText}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
