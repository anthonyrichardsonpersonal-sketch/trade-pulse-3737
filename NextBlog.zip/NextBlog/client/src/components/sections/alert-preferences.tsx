import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export default function AlertPreferences() {
  const [preferences, setPreferences] = useState({
    riskTolerance: "conservative",
    investmentAmount: "1000-5000",
    tradingExperience: "beginner",
    assetTypes: ["large-cap", "etfs"],
    preferredSectors: ["technology", "finance"],
    alertFrequency: "daily"
  });

  const handleRiskToleranceChange = (value: string) => {
    setPreferences(prev => ({ ...prev, riskTolerance: value }));
  };

  const handleAssetTypeChange = (assetType: string, checked: boolean) => {
    setPreferences(prev => ({
      ...prev,
      assetTypes: checked 
        ? [...prev.assetTypes, assetType]
        : prev.assetTypes.filter(type => type !== assetType)
    }));
  };

  const handleSectorChange = (sector: string, checked: boolean) => {
    setPreferences(prev => ({
      ...prev,
      preferredSectors: checked 
        ? [...prev.preferredSectors, sector]
        : prev.preferredSectors.filter(s => s !== sector)
    }));
  };

  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Customize Your Alerts</h2>
          <p className="text-xl text-slate-600">Tailor recommendations to match your trading style and risk tolerance</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="border border-slate-200">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Risk Preferences</h3>
                
                <div className="space-y-6">
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Risk Tolerance</Label>
                    <div className="grid grid-cols-3 gap-3">
                      {["conservative", "moderate", "aggressive"].map((risk) => (
                        <button
                          key={risk}
                          onClick={() => handleRiskToleranceChange(risk)}
                          className={`p-3 border-2 rounded-lg text-center font-medium capitalize transition-colors ${
                            preferences.riskTolerance === risk
                              ? "border-green-500 bg-green-50 text-green-700"
                              : "border-slate-300 hover:border-slate-400 text-slate-600"
                          }`}
                        >
                          {risk}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Investment Amount</Label>
                    <select 
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={preferences.investmentAmount}
                      onChange={(e) => setPreferences(prev => ({ ...prev, investmentAmount: e.target.value }))}
                    >
                      <option value="under-1000">Under $1,000</option>
                      <option value="1000-5000">$1,000 - $5,000</option>
                      <option value="5000-25000">$5,000 - $25,000</option>
                      <option value="over-25000">Over $25,000</option>
                    </select>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Trading Experience</Label>
                    <select 
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={preferences.tradingExperience}
                      onChange={(e) => setPreferences(prev => ({ ...prev, tradingExperience: e.target.value }))}
                    >
                      <option value="beginner">Beginner (&lt; 1 year)</option>
                      <option value="intermediate">Intermediate (1-3 years)</option>
                      <option value="advanced">Advanced (3+ years)</option>
                      <option value="professional">Professional</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="border border-slate-200">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Asset Preferences</h3>
                
                <div className="space-y-6">
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Asset Types</Label>
                    <div className="space-y-2">
                      {[
                        { id: "large-cap", label: "Large Cap Stocks" },
                        { id: "etfs", label: "ETFs" },
                        { id: "small-mid-cap", label: "Small/Mid Cap Stocks" },
                        { id: "crypto", label: "Crypto (Premium)" }
                      ].map((assetType) => (
                        <div key={assetType.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={assetType.id}
                            checked={preferences.assetTypes.includes(assetType.id)}
                            onCheckedChange={(checked) => handleAssetTypeChange(assetType.id, checked as boolean)}
                          />
                          <Label htmlFor={assetType.id} className="text-slate-700">
                            {assetType.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Preferred Sectors</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: "technology", label: "Technology" },
                        { id: "healthcare", label: "Healthcare" },
                        { id: "finance", label: "Finance" },
                        { id: "energy", label: "Energy" },
                        { id: "consumer", label: "Consumer" },
                        { id: "industrial", label: "Industrial" }
                      ].map((sector) => (
                        <div key={sector.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={sector.id}
                            checked={preferences.preferredSectors.includes(sector.id)}
                            onCheckedChange={(checked) => handleSectorChange(sector.id, checked as boolean)}
                          />
                          <Label htmlFor={sector.id} className="text-sm text-slate-700">
                            {sector.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-slate-700 mb-3 block">Alert Frequency</Label>
                    <select 
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={preferences.alertFrequency}
                      onChange={(e) => setPreferences(prev => ({ ...prev, alertFrequency: e.target.value }))}
                    >
                      <option value="daily">Daily (Trade of the Day)</option>
                      <option value="2-3-weekly">2-3 times per week</option>
                      <option value="weekly">Weekly digest</option>
                      <option value="opportunistic">As opportunities arise</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8 text-center">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 font-semibold">
              Save Preferences
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
