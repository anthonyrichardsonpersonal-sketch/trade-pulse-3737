import { TrendingUp } from "lucide-react";
import { FaTwitter, FaLinkedin, FaDiscord } from "react-icons/fa";

export default function Footer() {
  const platformLinks = [
    { name: "Dashboard", href: "#" },
    { name: "Trade Alerts", href: "#" },
    { name: "Analytics", href: "#" },
    { name: "Mobile App", href: "#" },
  ];

  const resourceLinks = [
    { name: "API Documentation", href: "#" },
    { name: "Trading Guide", href: "#" },
    { name: "Blog", href: "#" },
    { name: "Support", href: "#" },
  ];

  const companyLinks = [
    { name: "About Us", href: "#" },
    { name: "Careers", href: "#" },
    { name: "Privacy Policy", href: "#" },
    { name: "Terms of Service", href: "#" },
  ];

  return (
    <footer className="bg-slate-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-white h-4 w-4" />
              </div>
              <span className="text-xl font-bold">TradePulse</span>
            </div>
            <p className="text-slate-300 mb-6">
              Smart trading alerts powered by AI and technical analysis. 
              Make informed investment decisions with confidence.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                <FaTwitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                <FaLinkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">
                <FaDiscord className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-6">Platform</h3>
            <ul className="space-y-3 text-slate-300">
              {platformLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-6">Resources</h3>
            <ul className="space-y-3 text-slate-300">
              {resourceLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-6">Company</h3>
            <ul className="space-y-3 text-slate-300">
              {companyLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-700 mt-12 pt-8 text-center text-slate-300">
          <p>&copy; 2024 TradePulse. All rights reserved.</p>
          <p className="mt-2 text-sm">
            <span className="text-yellow-400">⚠️</span> 
            Trading involves risk. Past performance does not guarantee future results.
          </p>
        </div>
      </div>
    </footer>
  );
}
