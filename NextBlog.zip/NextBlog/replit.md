# TradePulse - AI-Powered Trading Platform

## Overview

TradePulse is a comprehensive full-stack trading platform that delivers daily AI-powered trade recommendations. The application combines technical analysis, market sentiment, and artificial intelligence to provide users with "Trade of the Day" alerts for stocks, ETFs, and optional crypto assets. Built with modern web technologies, it offers personalized trading recommendations, real-time market data, historical performance tracking, and customizable alert preferences.

The platform serves both beginner and experienced traders with features like risk tolerance customization, portfolio tracking, and comprehensive trade analytics. It follows a freemium model with basic free alerts and premium subscriptions for advanced features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built using React with TypeScript and Vite as the build tool. The UI leverages Radix UI components for accessibility and shadcn/ui for consistent design patterns. The application uses Wouter for lightweight client-side routing and TanStack Query for server state management and caching. Styling is handled through Tailwind CSS with custom CSS variables for theming support.

### Backend Architecture
The server runs on Express.js with TypeScript in ESM module format. It implements a RESTful API architecture with clear separation of concerns through route handlers and storage abstractions. The application uses an in-memory storage implementation (MemStorage) for development, with interfaces designed to support database integration later. The server includes comprehensive error handling, request logging, and development-specific features like Vite integration.

### Data Storage Solutions
The application uses Drizzle ORM with PostgreSQL as the target database. Schema definitions are centralized in a shared module, featuring tables for users, trades, market data, and alerts. The schema includes proper relationships, constraints, and indexing considerations. The system supports both development (in-memory) and production (PostgreSQL) storage patterns through interface abstractions.

### Authentication and Authorization
Currently implements basic session-based patterns with preparation for more robust authentication. The architecture includes user management endpoints and storage methods, with session handling configured through connect-pg-simple for PostgreSQL session storage. The system is designed to support role-based access control for different subscription tiers.

### Component Architecture
The frontend follows a modular component structure with sections (hero, pricing, market overview), charts (portfolio, trade visualizations), layout components (header, footer), and UI primitives. Components are organized by feature area and maintain clear separation between presentation and business logic.

### API Structure
RESTful endpoints are organized by resource type:
- User management (`/api/users/*`)
- Trade operations (`/api/trades/*`) 
- Market data (`/api/market/*`)
- Analytics (`/api/analytics/*`)
- External integrations (`/api/external/*`)

The API includes proper HTTP status codes, error handling, and request validation using Zod schemas.

### Real-time Features
The application includes WebSocket preparation for real-time market updates and push notifications. The frontend uses React Query for efficient data fetching and caching, with automatic background refetching for market data.

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting via @neondatabase/serverless
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- Session storage via connect-pg-simple for PostgreSQL-backed sessions

### UI and Styling
- **Radix UI**: Comprehensive set of accessible React components for complex UI patterns
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **shadcn/ui**: Pre-built component library built on Radix UI primitives
- **Recharts**: Charting library for data visualization (portfolio and trade charts)

### Development Tools
- **Vite**: Fast build tool with hot module replacement and optimized production builds
- **TypeScript**: Type safety across frontend, backend, and shared code
- **ESBuild**: Fast JavaScript bundler for server-side production builds
- **Replit Integration**: Development environment integration with cartographer and error overlay

### State Management
- **TanStack React Query**: Server state management, caching, and synchronization
- **Wouter**: Lightweight client-side routing solution
- **React Hook Form**: Form state management with Zod validation integration

### External API Integrations
- Market data providers (structure prepared for Alpha Vantage, IEX Cloud, or similar)
- Push notification services (structured for multiple delivery methods)
- Email services for alert delivery
- SMS services for premium notifications

The application architecture supports horizontal scaling, external service integration, and maintains clear separation between development and production environments.