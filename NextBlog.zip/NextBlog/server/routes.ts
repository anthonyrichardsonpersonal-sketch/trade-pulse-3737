import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTradeSchema, insertMarketDataSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  // Trade routes
  app.get("/api/trades", async (req, res) => {
    const trades = await storage.getTrades();
    res.json(trades);
  });

  app.get("/api/trades/today", async (req, res) => {
    const trade = await storage.getTradeOfTheDay();
    if (!trade) {
      return res.status(404).json({ error: "No trade of the day found" });
    }
    res.json(trade);
  });

  app.get("/api/trades/recent", async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const trades = await storage.getRecentTrades(limit);
    res.json(trades);
  });

  app.post("/api/trades", async (req, res) => {
    try {
      const tradeData = insertTradeSchema.parse(req.body);
      const trade = await storage.createTrade(tradeData);
      res.json(trade);
    } catch (error) {
      res.status(400).json({ error: "Invalid trade data" });
    }
  });

  app.put("/api/trades/:id", async (req, res) => {
    try {
      const updates = req.body;
      const trade = await storage.updateTrade(req.params.id, updates);
      if (!trade) {
        return res.status(404).json({ error: "Trade not found" });
      }
      res.json(trade);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  // Market data routes
  app.get("/api/market", async (req, res) => {
    const marketData = await storage.getMarketData();
    res.json(marketData);
  });

  app.get("/api/market/:symbol", async (req, res) => {
    const data = await storage.getMarketDataBySymbol(req.params.symbol);
    if (!data) {
      return res.status(404).json({ error: "Market data not found" });
    }
    res.json(data);
  });

  app.post("/api/market", async (req, res) => {
    try {
      const marketData = insertMarketDataSchema.parse(req.body);
      const data = await storage.createMarketData(marketData);
      res.json(data);
    } catch (error) {
      res.status(400).json({ error: "Invalid market data" });
    }
  });

  // External API integration route
  app.get("/api/external/stock/:symbol", async (req, res) => {
    const { symbol } = req.params;
    const apiKey = process.env.ALPHA_VANTAGE_API_KEY || process.env.FINANCIAL_API_KEY || "demo";
    
    try {
      const response = await fetch(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`
      );
      
      if (!response.ok) {
        throw new Error(`API response not ok: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data["Error Message"]) {
        return res.status(400).json({ error: "Invalid symbol or API limit reached" });
      }
      
      if (data["Note"]) {
        return res.status(429).json({ error: "API call frequency limit reached" });
      }
      
      const quote = data["Global Quote"];
      if (!quote) {
        return res.status(404).json({ error: "No data found for symbol" });
      }
      
      const formattedData = {
        symbol: quote["01. symbol"],
        price: parseFloat(quote["05. price"]).toFixed(2),
        change: parseFloat(quote["09. change"]).toFixed(2),
        changePercent: parseFloat(quote["10. change percent"].replace("%", "")).toFixed(2),
        volume: parseInt(quote["06. volume"]),
        lastUpdated: quote["07. latest trading day"]
      };
      
      res.json(formattedData);
    } catch (error) {
      console.error("External API error:", error);
      res.status(500).json({ error: "Failed to fetch stock data from external API" });
    }
  });

  // Analytics endpoint
  app.get("/api/analytics/performance", async (req, res) => {
    const trades = await storage.getTrades();
    const completedTrades = trades.filter(trade => trade.status === "completed");
    
    const winningTrades = completedTrades.filter(trade => 
      trade.result && parseFloat(trade.result) > 0
    );
    
    const winRate = completedTrades.length > 0 
      ? (winningTrades.length / completedTrades.length) * 100 
      : 0;
    
    const averageReturn = winningTrades.length > 0
      ? winningTrades.reduce((sum, trade) => sum + parseFloat(trade.result || "0"), 0) / winningTrades.length
      : 0;
    
    const averageHoldTime = completedTrades.length > 0
      ? completedTrades.reduce((sum, trade) => sum + (trade.duration || 0), 0) / completedTrades.length
      : 0;
    
    res.json({
      winRate: winRate.toFixed(1),
      averageReturn: averageReturn.toFixed(1),
      averageHoldTime: averageHoldTime.toFixed(1),
      totalTrades: completedTrades.length,
      winningTrades: winningTrades.length
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
