import { type User, type InsertUser, type Trade, type InsertTrade, type MarketData, type InsertMarketData, type Alert, type InsertAlert } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Trade methods
  getTrades(): Promise<Trade[]>;
  getTrade(id: string): Promise<Trade | undefined>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined>;
  getTradeOfTheDay(): Promise<Trade | undefined>;
  getRecentTrades(limit?: number): Promise<Trade[]>;

  // Market data methods
  getMarketData(): Promise<MarketData[]>;
  getMarketDataBySymbol(symbol: string): Promise<MarketData | undefined>;
  createMarketData(data: InsertMarketData): Promise<MarketData>;
  updateMarketData(symbol: string, updates: Partial<MarketData>): Promise<MarketData | undefined>;

  // Alert methods
  getUserAlerts(userId: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: string): Promise<Alert | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private trades: Map<string, Trade>;
  private marketData: Map<string, MarketData>;
  private alerts: Map<string, Alert>;

  constructor() {
    this.users = new Map();
    this.trades = new Map();
    this.marketData = new Map();
    this.alerts = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample data for demonstration
    const sampleTrade: Trade = {
      id: randomUUID(),
      symbol: "AAPL",
      companyName: "Apple Inc.",
      sector: "Technology",
      entryPrice: "150.42",
      targetPrice: "165.00",
      stopLoss: "142.50",
      currentPrice: "150.42",
      confidenceScore: 89,
      riskLevel: "Medium",
      timeHorizon: "2-4 weeks",
      rationale: [
        "Strong earnings beat with 15% revenue growth",
        "RSI indicates oversold conditions at 28",
        "Positive news sentiment from AI analysis",
        "Breaking above 50-day moving average"
      ],
      status: "active",
      result: null,
      duration: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.trades.set(sampleTrade.id, sampleTrade);

    // Initialize market data
    const marketIndices = [
      { symbol: "SPX", price: "4158.24", change: "49.82", changePercent: "1.2" },
      { symbol: "IXIC", price: "12845.78", change: "98.45", changePercent: "0.8" },
      { symbol: "DJI", price: "34256.90", change: "-102.34", changePercent: "-0.3" },
      { symbol: "RUT", price: "1967.85", change: "40.28", changePercent: "2.1" },
    ];

    marketIndices.forEach(index => {
      const data: MarketData = {
        id: randomUUID(),
        symbol: index.symbol,
        price: index.price,
        change: index.change,
        changePercent: index.changePercent,
        volume: null,
        marketCap: null,
        updatedAt: new Date(),
      };
      this.marketData.set(data.symbol, data);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser,
      riskTolerance: insertUser.riskTolerance || null,
      investmentAmount: insertUser.investmentAmount || null,
      tradingExperience: insertUser.tradingExperience || null,
      alertFrequency: insertUser.alertFrequency || null,
      assetTypes: insertUser.assetTypes || null,
      preferredSectors: insertUser.preferredSectors || null,
      plan: insertUser.plan || null,
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Trade methods
  async getTrades(): Promise<Trade[]> {
    return Array.from(this.trades.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getTrade(id: string): Promise<Trade | undefined> {
    return this.trades.get(id);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const trade: Trade = {
      ...insertTrade,
      result: insertTrade.result || null,
      duration: insertTrade.duration || null,
      status: insertTrade.status || null,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.trades.set(id, trade);
    return trade;
  }

  async updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined> {
    const trade = this.trades.get(id);
    if (!trade) return undefined;
    
    const updatedTrade = { ...trade, ...updates, updatedAt: new Date() };
    this.trades.set(id, updatedTrade);
    return updatedTrade;
  }

  async getTradeOfTheDay(): Promise<Trade | undefined> {
    const trades = await this.getTrades();
    return trades.find(trade => trade.status === "active") || trades[0];
  }

  async getRecentTrades(limit = 10): Promise<Trade[]> {
    const trades = await this.getTrades();
    return trades.slice(0, limit);
  }

  // Market data methods
  async getMarketData(): Promise<MarketData[]> {
    return Array.from(this.marketData.values());
  }

  async getMarketDataBySymbol(symbol: string): Promise<MarketData | undefined> {
    return this.marketData.get(symbol);
  }

  async createMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const id = randomUUID();
    const data: MarketData = {
      ...insertData,
      volume: insertData.volume || null,
      marketCap: insertData.marketCap || null,
      id,
      updatedAt: new Date(),
    };
    this.marketData.set(data.symbol, data);
    return data;
  }

  async updateMarketData(symbol: string, updates: Partial<MarketData>): Promise<MarketData | undefined> {
    const data = this.marketData.get(symbol);
    if (!data) return undefined;
    
    const updatedData = { ...data, ...updates, updatedAt: new Date() };
    this.marketData.set(symbol, updatedData);
    return updatedData;
  }

  // Alert methods
  async getUserAlerts(userId: string): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.userId === userId)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = {
      ...insertAlert,
      userId: insertAlert.userId || null,
      tradeId: insertAlert.tradeId || null,
      isRead: insertAlert.isRead || null,
      id,
      createdAt: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async markAlertAsRead(id: string): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, isRead: true };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }
}

export const storage = new MemStorage();
